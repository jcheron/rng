<?php
namespace controllers;
use Ubiquity\controllers\admin\UbiquityMyAdminBaseController;

class Admin extends UbiquityMyAdminBaseController{

}
